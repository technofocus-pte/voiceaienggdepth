"""Offline tests for the client-side plant tools. Run: python -m pytest tests -q"""

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

import plant_tools as pt  # noqa: E402


def call(session, name, **kwargs):
    return json.loads(session.dispatch(name, json.dumps(kwargs)))


def test_normalize_asset_ids():
    assert pt.normalize_asset_id("p 104") == "P-104"
    assert pt.normalize_asset_id("pump P104") == "P-104"
    assert pt.normalize_asset_id("cv-310") == "CV-310"


def test_asset_info_has_live_readings_and_alarms():
    r = call(pt.PlantSession(), "get_asset_info", asset_id="P104")
    assert r["found"] and r["model"] == "Fabrikam FP-300"
    assert r["live_readings"]["vibration_mm_s"] > 7 and r["active_alarms"]


def test_history_points_to_recent_seal_change():
    r = call(pt.PlantSession(), "get_maintenance_history", asset_id="P-104")
    assert "not re-aligned" in r["recent_work"][0]["summary"].lower() or "not re-aligned" in r["recent_work"][0]["summary"]


def test_spare_parts_out_of_stock_and_in_stock():
    s = pt.PlantSession()
    seal = call(s, "check_spare_parts", query="seal kit", asset_model="Fabrikam FP-300")["matches"][0]
    assert seal["qty_on_hand"] == 0 and seal["next_delivery"]
    shim = call(s, "check_spare_parts", query="shim")["matches"][0]
    assert shim["qty_on_hand"] > 0


def test_safety_gate_blocks_steps_until_loto(tmp_path, monkeypatch):
    monkeypatch.setattr(pt, "WORK_ORDER_FILE", tmp_path / "wo.json")
    s = pt.PlantSession("Test Tech")
    assert call(s, "log_step_completed", asset_id="P-104", step="Guard removed")["blocked_by_safety"]
    assert call(s, "create_work_order", asset_id="P-104", problem="x", root_cause="y", actions_taken="z")["blocked_by_safety"]
    assert not call(s, "confirm_lockout_tagout", asset_id="P-104", isolation_points_locked=["3B-07"], zero_energy_verified=False)["confirmed"]
    assert call(s, "confirm_lockout_tagout", asset_id="P-104", isolation_points_locked=["3B-07", "V-104S", "V-104D"], zero_energy_verified=True)["confirmed"]
    assert call(s, "log_step_completed", asset_id="p104", step="Guard removed", measurement="offset 0.18 mm")["logged"]
    wo = call(s, "create_work_order", asset_id="P-104", problem="High vibration", root_cause="Misalignment",
              actions_taken="Re-aligned coupling", parts_used=["GEN-SHIM-SS-KIT"])
    assert wo["created"] and wo["work_order"].startswith("WO-")
    saved = json.loads((tmp_path / "wo.json").read_text())
    assert saved[0]["loto"]["technician"] == "Test Tech" and len(saved[0]["steps"]) == 1


def test_unknown_tool_and_bad_args_return_errors():
    s = pt.PlantSession()
    assert "error" in json.loads(s.dispatch("launch_rocket", "{}"))
    assert "error" in json.loads(s.dispatch("get_asset_info", '{"wrong": 1}'))


def test_schemas_match_handlers():
    names = {f["name"] for f in pt.FUNCTION_SCHEMAS}
    assert names == {"get_asset_info", "get_maintenance_history", "check_spare_parts",
                     "confirm_lockout_tagout", "log_step_completed", "create_work_order"}
