"""
Exercise 2 - Give Torque its knowledge: equipment manuals + safety SOP.

  1. Create a vector store in the Foundry project and upload ../knowledge/*.md
  2. Create a versioned Foundry TOOLBOX that contains a file_search tool over it.
  3. Save the toolbox name/version to ../.lab_state.json for create_voice_agent.py

Why a toolbox? Voice agents reference server-side tools (file search, AI Search,
OpenAPI, web search, ...) through a versioned toolbox. Foundry runs these tools
for you - unlike the plant tools in plant_tools.py, which run on the client.

Usage:  python setup_knowledge.py
"""

from __future__ import annotations

from azure.ai.projects import AIProjectClient
from azure.ai.projects.models import FileSearchToolboxTool
from azure.identity import DefaultAzureCredential

import config


def main() -> None:
    endpoint = config.require_endpoint()
    files = sorted(config.KNOWLEDGE_DIR.glob("*.md"))
    if not files:
        raise SystemExit(f"No .md files found in {config.KNOWLEDGE_DIR}")

    with (
        DefaultAzureCredential() as credential,
        AIProjectClient(endpoint=endpoint, credential=credential, allow_preview=True) as project,
        project.get_openai_client() as openai_client,
    ):
        # 1) Vector store with the manuals
        vs = openai_client.vector_stores.create(name="torque-plant-manuals")
        print(f"Created vector store {vs.id}")
        for path in files:
            with path.open("rb") as fh:
                result = openai_client.vector_stores.files.upload_and_poll(vector_store_id=vs.id, file=fh)
            print(f"  indexed {path.name}: {result.status}")

        # 2) Versioned toolbox containing a file_search tool over that store
        toolbox = project.toolboxes.create_version(
            name=config.TOOLBOX_NAME,
            description="Torque knowledge: Zava Plant 2 equipment manuals (Fabrikam equipment) and the LOTO safety SOP.",
            tools=[
                FileSearchToolboxTool(
                    name="plant_manuals",
                    description="Search Fabrikam equipment service manuals (FP-300 pump, RS-75 compressor) "
                                "and SOP SAF-LOTO-01 for procedures, tolerances, torque specs and safety steps.",
                    vector_store_ids=[vs.id],
                    max_num_results=5,
                )
            ],
        )
        print(f"Created toolbox '{toolbox.name}' version {toolbox.version}")

    config.save_state(vector_store_id=vs.id, toolbox_name=toolbox.name, toolbox_version=toolbox.version)
    print(f"Saved to {config.STATE_FILE.name}. Next: python create_voice_agent.py")


if __name__ == "__main__":
    main()
