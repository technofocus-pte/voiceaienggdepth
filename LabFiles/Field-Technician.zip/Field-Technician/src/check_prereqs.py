"""
Lab B - Prerequisite / feasibility checker  ("Is this lab workable here?")

Runs every check the lab depends on and prints a GO / NO-GO report.
It creates only THROWAWAY test resources (names start with 'prereq-check-')
and deletes them again at the end.

Usage:
    python check_prereqs.py            # local + Azure checks
    python check_prereqs.py --local    # local machine checks only (no Azure needed)

Exit code 0 = GO, 1 = NO-GO.
"""

from __future__ import annotations

import argparse
import importlib
import json
import platform
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path

RESULTS: list[tuple[str, str, str]] = []   # (status, check, detail)
PASS, WARN, FAIL = "PASS", "WARN", "FAIL"


def record(status: str, check: str, detail: str = "") -> None:
    RESULTS.append((status, check, detail))
    icon = {"PASS": "[ OK ]", "WARN": "[WARN]", "FAIL": "[FAIL]"}[status]
    print(f"{icon} {check}" + (f"  - {detail}" if detail else ""))


# --------------------------------------------------------------------------- #
# Local machine checks
# --------------------------------------------------------------------------- #
def check_local() -> None:
    print("\n=== 1. Local machine ===")
    v = sys.version_info
    record(PASS if v >= (3, 10) else FAIL, "Python 3.10+", platform.python_version())

    az = shutil.which("az")
    if not az:
        record(FAIL, "Azure CLI installed", "az not found on PATH - install from https://aka.ms/installazurecli")
    else:
        try:
            out = subprocess.run([az, "version", "-o", "json"], capture_output=True, text=True, timeout=60).stdout
            ver = json.loads(out).get("azure-cli", "0")
            ok = tuple(int(x) for x in ver.split(".")[:2]) >= (2, 80)
            record(PASS if ok else WARN, "Azure CLI 2.80+", ver + ("" if ok else " - run 'az upgrade'"))
        except Exception as exc:
            record(WARN, "Azure CLI version", f"could not read version: {exc}")
        try:
            acct = subprocess.run([az, "account", "show", "-o", "json"], capture_output=True, text=True, timeout=60)
            if acct.returncode == 0:
                a = json.loads(acct.stdout)
                record(PASS, "Signed in with 'az login'", f"{a['user']['name']} / subscription '{a['name']}'")
            else:
                record(FAIL, "Signed in with 'az login'", "run 'az login' (and 'az account set --subscription <id>')")
        except Exception as exc:
            record(FAIL, "Signed in with 'az login'", str(exc))

    for pkg, label in [("azure.ai.projects", "azure-ai-projects[voice]"), ("azure.identity", "azure-identity"),
                       ("dotenv", "python-dotenv"), ("aiohttp", "aiohttp (voice extra)"), ("numpy", "numpy")]:
        try:
            mod = importlib.import_module(pkg)
            record(PASS, f"Package {label}", getattr(mod, "__version__", "installed"))
        except ImportError:
            record(FAIL, f"Package {label}", "run 'pip install -r requirements.txt'")
    try:
        from azure.ai.projects import __version__ as pv
        major, minor = (int(x) for x in pv.split(".")[:2])
        record(PASS if (major, minor) >= (2, 8) else FAIL, "azure-ai-projects >= 2.8 (voice agents)", pv)
    except Exception:
        pass

    try:
        import pyaudio
        pa = pyaudio.PyAudio()
        ins = [i for i in range(pa.get_device_count()) if pa.get_device_info_by_index(i).get("maxInputChannels", 0) > 0]
        outs = [i for i in range(pa.get_device_count()) if pa.get_device_info_by_index(i).get("maxOutputChannels", 0) > 0]
        record(PASS if ins else FAIL, "Microphone detected", f"{len(ins)} input device(s)")
        record(PASS if outs else FAIL, "Speaker/headset detected", f"{len(outs)} output device(s)")
        if ins:
            try:
                s = pa.open(format=pyaudio.paInt16, channels=1, rate=24000, input=True, frames_per_buffer=1200)
                s.read(1200, exception_on_overflow=False)
                s.close()
                record(PASS, "Microphone opens at 24 kHz", "OS microphone permission OK")
            except Exception as exc:
                record(FAIL, "Microphone opens at 24 kHz", f"{exc} - check OS microphone privacy settings")
        pa.terminate()
    except ImportError:
        record(WARN, "PyAudio installed", "missing - voice mode won't work; '--text' mode still works")


# --------------------------------------------------------------------------- #
# Azure / Foundry checks
# --------------------------------------------------------------------------- #
def check_azure() -> None:
    import config
    from azure.ai.projects import AIProjectClient
    from azure.ai.projects.models import (
        FileSearchToolboxTool,
        RealtimeConversationItemMessageUser,
        RealtimeConversationItemMessageUserContent,
        RealtimeConversationItemType,
        RealtimeServerEventError,
        RealtimeServerEventResponseAudioTranscriptDone,
        RealtimeServerEventResponseDone,
        VoiceAgentAudioConfig,
        VoiceAgentAudioOutputConfig,
        VoiceAgentDefinition,
        VoiceModelType,
        VoiceOutputModality,
        VoiceType,
    )
    from azure.identity import DefaultAzureCredential

    print("\n=== 2. Azure / Foundry project ===")
    endpoint = config.PROJECT_ENDPOINT
    if not endpoint or "<" in endpoint:
        record(FAIL, "FOUNDRY_PROJECT_ENDPOINT set in .env", "copy .env.example to .env and set the project endpoint")
        return
    record(PASS, "FOUNDRY_PROJECT_ENDPOINT set in .env", endpoint)

    suffix = uuid.uuid4().hex[:6]
    agent_name = f"prereq-check-voice-{suffix}"
    toolbox_name = f"prereq-check-toolbox-{suffix}"
    created_agent = vector_store_id = created_toolbox = None

    with DefaultAzureCredential() as credential:
        try:
            credential.get_token("https://ai.azure.com/.default")
            record(PASS, "Entra ID token for Foundry")
        except Exception as exc:
            record(FAIL, "Entra ID token for Foundry", f"{type(exc).__name__}: run 'az login' ({exc})")
            return

        with AIProjectClient(endpoint=endpoint, credential=credential, allow_preview=True) as project:
            # Project reachable + data-plane permission
            try:
                list(project.agents.list(limit=1))
                record(PASS, "Project reachable and agents can be listed", "role on project looks OK")
            except Exception as exc:
                record(FAIL, "Project reachable and agents can be listed",
                       f"{exc}. Check the endpoint and that you have 'Foundry User' on the project.")
                return

            # Voice agent preview + managed realtime model
            try:
                created_agent = project.agents.create_version(
                    agent_name=agent_name,
                    definition=VoiceAgentDefinition(
                        model_type=VoiceModelType.MANAGED, model=config.VOICE_MODEL,
                        instructions="You are a test agent. Reply with exactly: ready.",
                        audio=VoiceAgentAudioConfig(output=VoiceAgentAudioOutputConfig(
                            voice="en-US-AvaNeural", voice_type=VoiceType.AZURE_STANDARD)),
                        output_modalities=[VoiceOutputModality.AUDIO],
                    ),
                )
                record(PASS, "Voice agents (preview) enabled + model available",
                       f"created test agent with model '{config.VOICE_MODEL}'")
            except Exception as exc:
                record(FAIL, "Voice agents (preview) enabled + model available",
                       f"{exc}. Preview may not be enabled for this subscription/region, or the model "
                       f"'{config.VOICE_MODEL}' isn't available. THIS IS A LAB BLOCKER.")

            # Realtime WebSocket round trip (network/proxy + model actually answers)
            if created_agent:
                try:
                    t0 = time.time()
                    heard = ""
                    with project.beta.voice_agents.realtime.connect(agent_name=agent_name) as conn:
                        conn.conversation.item.create(item=RealtimeConversationItemMessageUser(
                            type=RealtimeConversationItemType.MESSAGE,
                            content=[RealtimeConversationItemMessageUserContent(type="input_text", text="Are you ready?")]))
                        conn.response.create()
                        while True:
                            ev = conn.recv(timeout=45)
                            if isinstance(ev, RealtimeServerEventResponseAudioTranscriptDone):
                                heard = ev.transcript
                            elif isinstance(ev, RealtimeServerEventError):
                                raise RuntimeError(ev.error.message)
                            elif isinstance(ev, RealtimeServerEventResponseDone):
                                break
                    record(PASS, "Realtime WebSocket session (wss://, port 443)",
                           f"agent replied '{heard.strip()[:40]}' in {time.time() - t0:.1f}s")
                except Exception as exc:
                    record(FAIL, "Realtime WebSocket session (wss://, port 443)",
                           f"{exc}. A corporate proxy/firewall may block WebSockets to *.services.ai.azure.com.")

            # Vector store + file search (knowledge)
            try:
                with project.get_openai_client() as oai:
                    vs = oai.vector_stores.create(name=f"prereq-check-{suffix}")
                    vector_store_id = vs.id
                    with tempfile.NamedTemporaryFile("w", suffix=".md", delete=False) as tf:
                        tf.write("# Test\nThe torque for test bolts is 10 N m.\n")
                    with open(tf.name, "rb") as fh:
                        r = oai.vector_stores.files.upload_and_poll(vector_store_id=vs.id, file=fh)
                    Path(tf.name).unlink(missing_ok=True)
                    record(PASS if r.status == "completed" else WARN, "Vector store + file indexing", r.status)
            except Exception as exc:
                record(FAIL, "Vector store + file indexing", f"{exc}")

            # Toolbox
            if vector_store_id:
                try:
                    created_toolbox = project.toolboxes.create_version(
                        name=toolbox_name, description="prereq check",
                        tools=[FileSearchToolboxTool(name="test_search", vector_store_ids=[vector_store_id])])
                    record(PASS, "Foundry toolbox creation", f"{created_toolbox.name} v{created_toolbox.version}")
                except Exception as exc:
                    record(FAIL, "Foundry toolbox creation", f"{exc}")

            # Application Insights connection (needed for Exercise 7 traces/monitoring)
            try:
                conns = list(project.connections.list())
                has_ai = any("insight" in str(getattr(c, "type", "")).lower() for c in conns)
                record(PASS if has_ai else WARN, "Application Insights connected to project",
                       "connected" if has_ai else "not found - connect it (Agents > Traces > Connect) for Exercise 7")
            except Exception as exc:
                record(WARN, "Application Insights connected to project", f"could not check: {exc}")

            # Clean-up
            print("\nCleaning up test resources ...")
            for label, fn in [
                ("test voice agent", lambda: created_agent and project.agents.delete(agent_name=agent_name, force=True)),
                ("test toolbox", lambda: created_toolbox and project.toolboxes.delete(toolbox_name)),
                ("test vector store", lambda: vector_store_id and project.get_openai_client().vector_stores.delete(vector_store_id)),
            ]:
                try:
                    fn()
                except Exception as exc:
                    print(f"  could not delete {label}: {exc} (delete it manually in the portal)")


def summary() -> int:
    fails = [r for r in RESULTS if r[0] == FAIL]
    warns = [r for r in RESULTS if r[0] == WARN]
    print("\n" + "=" * 70)
    print(f"RESULT: {len(RESULTS) - len(fails) - len(warns)} passed, {len(warns)} warnings, {len(fails)} failed")
    if fails:
        print("DECISION: NO-GO - fix every FAIL above (or use the instructor-demo fallback).")
        for _, check, detail in fails:
            print(f"  * {check}: {detail}")
    else:
        print("DECISION: GO" + (" (review warnings)" if warns else ""))
    print("=" * 70)
    return 1 if fails else 0


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--local", action="store_true", help="only check the local machine")
    args = p.parse_args()
    check_local()
    if not args.local:
        check_azure()
    sys.exit(summary())


if __name__ == "__main__":
    main()
