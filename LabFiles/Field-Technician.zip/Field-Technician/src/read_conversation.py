"""
Exercise 7 - Review a persisted conversation (store=True on the voice agent).

Prints the transcript of the last Torque session (or a given conversation id)
and saves the full-call recording as a WAV file. These are the raw materials
for quality review and conversation-level evaluation.

Usage:
    python read_conversation.py                  # last session from .lab_state.json
    python read_conversation.py <conversation_id>
"""

from __future__ import annotations

import sys

from azure.ai.projects import AIProjectClient
from azure.ai.projects.models import (
    RealtimeConversationItemMessageAssistant,
    RealtimeConversationItemMessageUser,
)
from azure.identity import DefaultAzureCredential

import config


def line_for(item) -> str:
    if isinstance(item, (RealtimeConversationItemMessageUser, RealtimeConversationItemMessageAssistant)):
        text = " ".join((getattr(p, "transcript", None) or getattr(p, "text", None) or "").strip() for p in item.content)
        who = "Tech  " if item.role == "user" else "Torque"
        return f"{who}: {text.strip()}"
    name = getattr(item, "name", None)
    return f"  [{item.type}{': ' + name if name else ''}]"


def main() -> None:
    conv_id = sys.argv[1] if len(sys.argv) > 1 else config.load_state().get("last_conversation_id")
    if not conv_id:
        raise SystemExit("No conversation id. Run torque_app.py first (the agent must have store=True).")

    with (
        DefaultAzureCredential() as credential,
        AIProjectClient(endpoint=config.require_endpoint(), credential=credential, allow_preview=True) as project,
    ):
        conversations = project.beta.voice_agents.conversations
        conv = conversations.get(config.AGENT_NAME, conv_id)
        print(f"Conversation {conv.id}  status={conv.status}  created={conv.created_at}\n")
        for item in conversations.list_items(config.AGENT_NAME, conv_id, order="asc"):
            print(line_for(item))

        try:
            out = config.ROOT / f"conversation_{conv_id[-8:]}.wav"
            with out.open("wb") as f:
                for chunk in conversations.download_audio(config.AGENT_NAME, conv_id):
                    f.write(chunk)
            print(f"\nFull-call recording saved to {out.name}")
        except Exception as exc:  # audio may still be finalising right after the call
            print(f"\n(Recording not available yet: {exc}. Try again in a minute.)")


if __name__ == "__main__":
    main()
