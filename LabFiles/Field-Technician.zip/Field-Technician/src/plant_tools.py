"""
Client-side plant tools for "Torque", the hands-free field technician assistant.

Why do these run in the CLIENT (the plant-floor app) and not in the cloud?
  * The data is local: live sensor readings come from the plant historian or
    edge gateway next to the machine, and the CMMS (maintenance system) sits
    on the plant network. None of these are public HTTPS APIs.
  * The voice agent declares these as `function` tools. During a live session
    the service sends the function call to this app, the app runs it here, and
    sends the result back over the same WebSocket.

Safety in code, not just in the prompt: `log_step_completed` and
`create_work_order` refuse to run until `confirm_lockout_tagout` has been
called for that asset in this session. The agent's instructions say the same
thing, but a guardrail that matters belongs in code too.
"""

from __future__ import annotations

import json
import random
import re
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

DATA_DIR = Path(__file__).resolve().parent.parent / "plant_data"
WORK_ORDER_FILE = DATA_DIR / "work_orders.json"


def _load(name: str) -> Any:
    with open(DATA_DIR / name, encoding="utf-8") as f:
        return json.load(f)


def normalize_asset_id(raw: str) -> str:
    """'p 104', 'P104', 'pump p-104' -> 'P-104'; 'cv310' -> 'CV-310'."""
    m = re.search(r"([A-Za-z]{1,3})\s*-?\s*(\d{2,4})", raw or "")
    return f"{m.group(1).upper()}-{m.group(2)}" if m else (raw or "").strip().upper()


class PlantSession:
    """Holds per-session state (LOTO confirmations, completed steps) for one technician."""

    def __init__(self, technician: str = "Technician") -> None:
        self.technician = technician
        self.loto_confirmed: dict[str, dict] = {}
        self.steps: dict[str, list[dict]] = {}

    # ------------------------------------------------------------------ #
    # Tools
    # ------------------------------------------------------------------ #
    def get_asset_info(self, asset_id: str) -> dict:
        aid = normalize_asset_id(asset_id)
        asset = next((a for a in _load("assets.json") if a["asset_id"] == aid), None)
        if not asset:
            return {"found": False, "message": f"No asset '{asset_id}'. Known assets: P-104, C-201, CV-310."}
        live = {k: round(v * random.uniform(0.98, 1.02), 1) for k, v in asset["live"].items()}  # simulate live sensors
        return {"found": True, **{k: v for k, v in asset.items() if k != "live"}, "live_readings": live,
                "read_at": datetime.now().strftime("%H:%M:%S")}

    def get_maintenance_history(self, asset_id: str) -> dict:
        aid = normalize_asset_id(asset_id)
        history = _load("maintenance_history.json").get(aid)
        if history is None:
            return {"found": False, "message": f"No history for '{asset_id}'."}
        return {"found": True, "asset_id": aid, "recent_work": history}

    def check_spare_parts(self, query: str, asset_model: str | None = None) -> dict:
        q = query.lower()
        words = [w for w in re.split(r"\W+", q) if len(w) > 2]
        hits = []
        for p in _load("spare_parts.json"):
            text = f"{p['part_number']} {p['description']}".lower()
            fits = asset_model is None or "*" in p["fits"] or any(asset_model.lower() in f.lower() for f in p["fits"])
            if fits and (q in text or any(w in text for w in words)):
                hits.append(p)
        return {"query": query, "matches": hits[:5]} if hits else {"query": query, "matches": [], "message": "No matching parts."}

    def confirm_lockout_tagout(self, asset_id: str, isolation_points_locked: list[str], zero_energy_verified: bool) -> dict:
        aid = normalize_asset_id(asset_id)
        if not zero_energy_verified:
            return {"confirmed": False, "message": "Zero-energy verification is required. Ask the technician to try-start and check gauges first."}
        record = {"asset_id": aid, "technician": self.technician, "isolation_points": isolation_points_locked,
                  "confirmed_at": datetime.now().isoformat(timespec="seconds")}
        self.loto_confirmed[aid] = record
        return {"confirmed": True, **record}

    def log_step_completed(self, asset_id: str, step: str, measurement: str | None = None) -> dict:
        aid = normalize_asset_id(asset_id)
        if aid not in self.loto_confirmed:
            return {"logged": False, "blocked_by_safety": True,
                    "message": "Lockout/tagout has not been confirmed for this asset. Do not guide repair steps yet."}
        entry = {"step": step, "measurement": measurement, "at": datetime.now().strftime("%H:%M:%S")}
        self.steps.setdefault(aid, []).append(entry)
        return {"logged": True, "asset_id": aid, "steps_so_far": len(self.steps[aid]), **entry}

    def create_work_order(self, asset_id: str, problem: str, root_cause: str, actions_taken: str,
                          parts_used: list[str] | None = None, follow_up: str | None = None) -> dict:
        aid = normalize_asset_id(asset_id)
        if aid not in self.loto_confirmed:
            return {"created": False, "blocked_by_safety": True,
                    "message": "Cannot close out hands-on work without a confirmed lockout/tagout record."}
        wo = {
            "work_order": "WO-" + uuid.uuid4().hex[:5].upper(), "asset_id": aid, "technician": self.technician,
            "created_at": datetime.now().isoformat(timespec="seconds"), "problem": problem, "root_cause": root_cause,
            "actions_taken": actions_taken, "parts_used": parts_used or [], "follow_up": follow_up,
            "loto": self.loto_confirmed[aid], "steps": self.steps.get(aid, []),
        }
        existing = json.loads(WORK_ORDER_FILE.read_text(encoding="utf-8")) if WORK_ORDER_FILE.exists() else []
        existing.append(wo)
        WORK_ORDER_FILE.write_text(json.dumps(existing, indent=2), encoding="utf-8")
        return {"created": True, "work_order": wo["work_order"], "asset_id": aid}

    # ------------------------------------------------------------------ #
    # Dispatch: the realtime client calls this with the function name and
    # the JSON arguments the model produced.
    # ------------------------------------------------------------------ #
    def dispatch(self, name: str, arguments_json: str) -> str:
        handlers: dict[str, Callable[..., dict]] = {
            "get_asset_info": self.get_asset_info,
            "get_maintenance_history": self.get_maintenance_history,
            "check_spare_parts": self.check_spare_parts,
            "confirm_lockout_tagout": self.confirm_lockout_tagout,
            "log_step_completed": self.log_step_completed,
            "create_work_order": self.create_work_order,
        }
        if name not in handlers:
            return json.dumps({"error": f"Unknown tool '{name}'."})
        try:
            args = json.loads(arguments_json or "{}")
            return json.dumps(handlers[name](**args), ensure_ascii=False)
        except Exception as exc:  # return errors to the model instead of crashing the call
            return json.dumps({"error": f"{type(exc).__name__}: {exc}"})


# ---------------------------------------------------------------------- #
# JSON schemas the VOICE AGENT DEFINITION registers for these functions.
# (Used by create_voice_agent.py -> VoiceAgentFunctionTool.)
# ---------------------------------------------------------------------- #
FUNCTION_SCHEMAS: list[dict] = [
    {
        "name": "get_asset_info",
        "description": "Get an asset's model, location, energy sources, status, active alarms, baseline values and LIVE sensor readings.",
        "parameters": {"type": "object", "properties": {
            "asset_id": {"type": "string", "description": "Asset tag, e.g. P-104, C-201, CV-310."}},
            "required": ["asset_id"]},
    },
    {
        "name": "get_maintenance_history",
        "description": "Get recent work orders for an asset. Use it to spot work that may have caused the current problem.",
        "parameters": {"type": "object", "properties": {
            "asset_id": {"type": "string", "description": "Asset tag, e.g. P-104."}},
            "required": ["asset_id"]},
    },
    {
        "name": "check_spare_parts",
        "description": "Check stock and bin location of spare parts.",
        "parameters": {"type": "object", "properties": {
            "query": {"type": "string", "description": "Part description or number, e.g. 'drive end bearing' or 'seal kit'."},
            "asset_model": {"type": "string", "description": "Optional equipment model to filter by, e.g. Fabrikam FP-300."}},
            "required": ["query"]},
    },
    {
        "name": "confirm_lockout_tagout",
        "description": "Record that the technician has personally applied lockout/tagout and verified zero energy. Call only after they explicitly say so.",
        "parameters": {"type": "object", "properties": {
            "asset_id": {"type": "string"},
            "isolation_points_locked": {"type": "array", "items": {"type": "string"},
                                        "description": "Isolation points the technician said they locked, e.g. ['breaker 3B-07', 'V-104S', 'V-104D']."},
            "zero_energy_verified": {"type": "boolean", "description": "True only if the technician said they verified zero energy."}},
            "required": ["asset_id", "isolation_points_locked", "zero_energy_verified"]},
    },
    {
        "name": "log_step_completed",
        "description": "Log a repair step the technician has finished, with any measurement they read out.",
        "parameters": {"type": "object", "properties": {
            "asset_id": {"type": "string"},
            "step": {"type": "string", "description": "Short description, e.g. 'Coupling guard removed'."},
            "measurement": {"type": "string", "description": "Optional reading, e.g. 'parallel offset 0.18 mm'."}},
            "required": ["asset_id", "step"]},
    },
    {
        "name": "create_work_order",
        "description": "Create the completed corrective work order at the end of the job.",
        "parameters": {"type": "object", "properties": {
            "asset_id": {"type": "string"},
            "problem": {"type": "string"},
            "root_cause": {"type": "string"},
            "actions_taken": {"type": "string"},
            "parts_used": {"type": "array", "items": {"type": "string"}},
            "follow_up": {"type": "string", "description": "Any follow-up needed, e.g. 'recheck vibration in 24 h'."}},
            "required": ["asset_id", "problem", "root_cause", "actions_taken"]},
    },
]
