"""
Exercise 4 - "Torque" plant-floor app: a hands-free realtime client for the
Foundry voice agent, which runs the client-side plant tools.

    headset mic ──► (optional factory-noise mix) ──► Foundry voice agent "Torque"
                                                         │  real-time model, voice, VAD,
                                                         │  noise suppression, toolbox (manuals)
    headset ◄── reply audio ◄────────────────────────────┤
                                                         │ function_call (get_asset_info, ...)
    plant_tools.PlantSession  ◄──────────────────────────┘ ──► result sent back on the same socket

Note what this client does NOT send: no model, no instructions, no voice and no
session.update. The voice agent definition in Foundry owns all of that.

Usage:
    python torque_app.py                                  # talk (headset strongly recommended)
    python torque_app.py --noise-file ../audio/factory_noise.wav --noise-level 0.6
    python torque_app.py --text                           # type instead of talking
    python torque_app.py --version 3                      # pin a specific agent version
"""

from __future__ import annotations

import argparse
import asyncio
import queue
import sys
import wave
from typing import Optional

from azure.ai.projects.aio import AIProjectClient
from azure.ai.projects.models import (
    RealtimeConversationItemFunctionCallOutput,
    RealtimeConversationItemMessageUser,
    RealtimeConversationItemMessageUserContent,
    RealtimeConversationItemType,
    RealtimeServerEventConversationItemInputAudioTranscriptionCompleted,
    RealtimeServerEventError,
    RealtimeServerEventInputAudioBufferSpeechStarted,
    RealtimeServerEventResponseAudioDelta,
    RealtimeServerEventResponseAudioTranscriptDone,
    RealtimeServerEventResponseCreated,
    RealtimeServerEventResponseDone,
    RealtimeServerEventResponseFunctionCallArgumentsDone,
    RealtimeServerEventSessionCreated,
)
from azure.identity.aio import DefaultAzureCredential

import config
from plant_tools import PlantSession

try:
    import pyaudio
except ImportError:
    pyaudio = None
try:
    import numpy as np
except ImportError:
    np = None

RATE, CHUNK = 24000, 1200  # PCM16 mono 24 kHz, 50 ms frames


class NoiseMixer:
    """Mixes a looping WAV (24 kHz, mono, 16-bit) into the mic signal so that
    every learner tests against the SAME factory noise."""

    def __init__(self, path: str, level: float):
        if np is None:
            sys.exit("numpy is required for --noise-file (pip install numpy)")
        with wave.open(path, "rb") as w:
            if (w.getframerate(), w.getnchannels(), w.getsampwidth()) != (RATE, 1, 2):
                sys.exit("Noise file must be 24 kHz, mono, 16-bit. Use audio/generate_factory_noise.py.")
            self.noise = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32)
        self.level, self.pos = level, 0

    def mix(self, pcm: bytes) -> bytes:
        sig = np.frombuffer(pcm, dtype=np.int16).astype(np.float32)
        idx = (np.arange(len(sig)) + self.pos) % len(self.noise)
        self.pos = (self.pos + len(sig)) % len(self.noise)
        return np.clip(sig + self.noise[idx] * self.level, -32768, 32767).astype(np.int16).tobytes()


class Audio:
    def __init__(self, conn, capture: bool, mixer: Optional[NoiseMixer]):
        self.conn, self.capture, self.mixer = conn, capture, mixer
        self.pa = pyaudio.PyAudio()
        self.q: "queue.Queue[tuple[int, bytes]]" = queue.Queue()
        self.base = self.seq = 0
        self.pending = None
        self.streams = []

    def start(self) -> None:
        loop = asyncio.get_running_loop()
        remaining = b""

        def play(_i, frames, *_):
            nonlocal remaining
            want = frames * 2
            out, remaining = remaining[:want], remaining[want:]
            while len(out) < want:
                try:
                    s, data = self.q.get_nowait()
                except queue.Empty:
                    out += bytes(want - len(out))
                    break
                if s < self.base:
                    continue
                take = want - len(out)
                out, remaining = out + data[:take], data[take:]
            return (out, pyaudio.paContinue)

        self.streams.append(self.pa.open(format=pyaudio.paInt16, channels=1, rate=RATE, output=True,
                                         frames_per_buffer=CHUNK, stream_callback=play))
        if self.capture:
            def rec(data, *_):
                if self.pending is not None and not self.pending.done():
                    return (None, pyaudio.paContinue)  # backpressure: drop a frame rather than queue forever
                if self.mixer:
                    data = self.mixer.mix(data)
                self.pending = asyncio.run_coroutine_threadsafe(self.conn.input_audio_buffer.append(audio=data), loop)
                return (None, pyaudio.paContinue)

            self.streams.append(self.pa.open(format=pyaudio.paInt16, channels=1, rate=RATE, input=True,
                                             frames_per_buffer=CHUNK, stream_callback=rec))

    def play(self, pcm: bytes) -> None:
        self.q.put((self.seq, pcm))
        self.seq += 1

    def barge_in(self) -> None:
        self.base = self.seq
        self.seq += 1

    def close(self) -> None:
        for s in self.streams:
            s.stop_stream()
            s.close()
        self.pa.terminate()


async def send_text(conn, text: str) -> None:
    await conn.conversation.item.create(item=RealtimeConversationItemMessageUser(
        type=RealtimeConversationItemType.MESSAGE,
        content=[RealtimeConversationItemMessageUserContent(type="input_text", text=text)]))
    await conn.response.create()


async def type_loop(conn) -> None:
    while True:
        line = (await asyncio.to_thread(input, "")).strip()
        if line.lower() in {"exit", "quit"}:
            raise KeyboardInterrupt
        if line:
            await send_text(conn, line)


async def run(args) -> None:
    if pyaudio is None:
        sys.exit("pyaudio is required (see the lab guide prerequisites).")
    plant = PlantSession(technician=config.TECHNICIAN)
    mixer = NoiseMixer(args.noise_file, args.noise_level) if args.noise_file else None
    extra_query = {"x-agent-version-override": str(args.version)} if args.version else None

    async with (
        DefaultAzureCredential() as credential,
        AIProjectClient(endpoint=config.require_endpoint(), credential=credential, allow_preview=True) as project,
    ):
        print(f"Connecting to voice agent '{config.AGENT_NAME}'" + (f" v{args.version}" if args.version else "") + " ...")
        async with project.beta.voice_agents.realtime.connect(agent_name=config.AGENT_NAME, extra_query=extra_query) as conn:
            audio = Audio(conn, capture=not args.text, mixer=mixer)
            audio.start()
            typing = asyncio.create_task(type_loop(conn)) if args.text else None
            print("=== Torque is live. " + ("Type and press Enter." if args.text else "Speak naturally.")
                  + (" [factory noise ON]" if mixer else "") + " Ctrl+C to end. ===\n")

            response_active = False
            pending_outputs: list[tuple[str, str]] = []
            try:
                async for ev in conn:
                    if isinstance(ev, RealtimeServerEventSessionCreated):
                        if ev.conversation_id:
                            config.save_state(last_conversation_id=ev.conversation_id)
                    elif isinstance(ev, RealtimeServerEventInputAudioBufferSpeechStarted):
                        audio.barge_in()                          # stop local playback immediately
                        if response_active:
                            await conn.response.cancel()          # and stop the server-side response
                            print("   (interrupted - listening)")
                    elif isinstance(ev, RealtimeServerEventConversationItemInputAudioTranscriptionCompleted):
                        print(f"Tech:   {ev.transcript.strip()}")
                    elif isinstance(ev, RealtimeServerEventResponseCreated):
                        response_active = True
                    elif isinstance(ev, RealtimeServerEventResponseAudioDelta):
                        audio.play(ev.delta)
                    elif isinstance(ev, RealtimeServerEventResponseAudioTranscriptDone):
                        print(f"Torque: {ev.transcript}")
                    elif isinstance(ev, RealtimeServerEventResponseFunctionCallArgumentsDone):
                        # The voice agent asked THIS app to run a plant tool.
                        result = plant.dispatch(ev.name, ev.arguments)
                        print(f"   [tool] {ev.name}({ev.arguments}) -> {result[:160]}{'...' if len(result) > 160 else ''}")
                        pending_outputs.append((ev.call_id, result))
                    elif isinstance(ev, RealtimeServerEventResponseDone):
                        response_active = False
                        if pending_outputs:
                            # Send tool results only after the function-call response has finished,
                            # then ask the agent to continue with them.
                            for call_id, output in pending_outputs:
                                await conn.conversation.item.create(
                                    item=RealtimeConversationItemFunctionCallOutput(call_id=call_id, output=output))
                            pending_outputs = []
                            await conn.response.create()
                    elif isinstance(ev, RealtimeServerEventError):
                        print(f"   [error] {ev.error.message}")
            except (KeyboardInterrupt, asyncio.CancelledError):
                pass
            finally:
                if typing:
                    typing.cancel()
                audio.close()
    print("\nSession ended. Conversation id saved - run read_conversation.py to review it.")


def main() -> None:
    p = argparse.ArgumentParser(description="Torque hands-free plant-floor client")
    p.add_argument("--text", action="store_true", help="type instead of speaking")
    p.add_argument("--version", help="pin a specific voice agent version")
    p.add_argument("--noise-file", help="WAV (24 kHz mono 16-bit) to mix into the mic signal")
    p.add_argument("--noise-level", type=float, default=0.5, help="noise gain, 0.0-1.5")
    try:
        asyncio.run(run(p.parse_args()))
    except KeyboardInterrupt:
        print("\nGoodbye!")


if __name__ == "__main__":
    main()
