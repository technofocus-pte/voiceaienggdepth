"""Shared settings for Lab B. Values come from ../.env; lab state from ../.lab_state.json."""

from __future__ import annotations

import json
import os
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")

PROJECT_ENDPOINT = os.environ.get("FOUNDRY_PROJECT_ENDPOINT", "")
AGENT_NAME = os.environ.get("FOUNDRY_VOICE_AGENT_NAME", "torque-field-assistant")
VOICE_MODEL = os.environ.get("FOUNDRY_VOICE_AGENT_MODEL", "gpt-realtime")
VOICE_NAME = os.environ.get("VOICE_NAME", "en-US-Andrew:DragonHDLatestNeural")
TECHNICIAN = os.environ.get("TECHNICIAN_NAME", "Technician")
TOOLBOX_NAME = os.environ.get("TOOLBOX_NAME", "torque-knowledge")

KNOWLEDGE_DIR = ROOT / "knowledge"
STATE_FILE = ROOT / ".lab_state.json"


def load_state() -> dict:
    return json.loads(STATE_FILE.read_text()) if STATE_FILE.exists() else {}


def save_state(**updates) -> dict:
    state = load_state()
    state.update(updates)
    STATE_FILE.write_text(json.dumps(state, indent=2))
    return state


def require_endpoint() -> str:
    if not PROJECT_ENDPOINT or "<" in PROJECT_ENDPOINT:
        raise SystemExit("Set FOUNDRY_PROJECT_ENDPOINT in .env (copy .env.example first).")
    return PROJECT_ENDPOINT
