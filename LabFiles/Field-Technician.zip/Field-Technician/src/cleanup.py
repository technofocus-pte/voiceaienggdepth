"""Delete the Torque voice agent, its toolbox and the manuals vector store."""

from azure.ai.projects import AIProjectClient
from azure.identity import DefaultAzureCredential

import config

state = config.load_state()
with (
    DefaultAzureCredential() as credential,
    AIProjectClient(endpoint=config.require_endpoint(), credential=credential, allow_preview=True) as project,
):
    for label, action in [
        ("voice agent", lambda: project.agents.delete(agent_name=config.AGENT_NAME, force=True)),
        ("toolbox", lambda: project.toolboxes.delete(state["toolbox_name"])),
        ("vector store", lambda: project.get_openai_client().vector_stores.delete(state["vector_store_id"])),
    ]:
        try:
            action()
            print(f"Deleted {label}.")
        except Exception as exc:
            print(f"Skipped {label}: {exc}")
config.STATE_FILE.unlink(missing_ok=True)
