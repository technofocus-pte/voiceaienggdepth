"""
Exercise 3 - Create "Torque" as a Microsoft Foundry VOICE AGENT (preview).

Path 3, "voice is the agent": ONE versioned definition owns everything -
real-time model, instructions, greeting, voice, turn detection, noise
suppression, transcription, tools and knowledge. Every run of this script
creates a NEW immutable version.

Usage:
    python create_voice_agent.py                        # full agent
    python create_voice_agent.py --noise off            # Exercise 6 experiment
    python create_voice_agent.py --turn-detection server
    python create_voice_agent.py --no-toolbox           # if Exercise 2 isn't done yet
"""

from __future__ import annotations

import argparse

from azure.ai.projects import AIProjectClient
from azure.ai.projects.models import (
    RealtimeAudioFormatsAudioPcm,
    RealtimeFunctionToolParameters,
    VoiceAgentAudioConfig,
    VoiceAgentAudioInputConfig,
    VoiceAgentAudioOutputConfig,
    VoiceAgentAzureSemanticVadTurnDetection,
    VoiceAgentDefinition,
    VoiceAgentEchoCancellation,
    VoiceAgentEndConversationSystemTool,
    VoiceAgentFunctionTool,
    VoiceAgentInputTranscription,
    VoiceAgentNoiseReduction,
    VoiceAgentServerVadTurnDetection,
    VoiceAgentTemplateGreetingConfig,
    VoiceAgentToolboxTool,
    VoiceModelType,
    VoiceOutputModality,
    VoiceType,
)
from azure.identity import DefaultAzureCredential

import config
from plant_tools import FUNCTION_SCHEMAS

INSTRUCTIONS = """
You are Torque, a hands-free maintenance assistant for technicians at Zava's
Dayton, Ohio Plant 2. The technician is standing at a machine with their hands busy,
often wearing gloves and ear defenders on a noisy floor. You talk with them
through a headset.

## How to speak
- Short, clear sentences. One instruction at a time, then wait for "done",
  "next", or a question. Never read a whole procedure in one go.
- Say numbers digit by digit when precision matters: "zero point zero five
  millimetres", "forty-five newton metres".
- No lists, markdown or symbols. If you are interrupted, stop and answer the new
  question.

## General questions vs. asset work
- If the technician asks a general question about a procedure, tolerance,
  torque value, part or safety rule (for example "what's the torque for the
  motor foot bolts on an FP-300?"), answer it directly from plant_manuals.
  Do NOT call get_asset_info for that. FP-300 and RS-75 are equipment MODELS,
  not asset tags.
- Only call get_asset_info when the technician names a specific asset tag
  (P-104, C-201 or CV-310) or asks about a machine's live condition.
- If you're not sure what you heard (for example an asset tag that isn't
  P-104, C-201 or CV-310), ask them to repeat it. Don't guess.
- Only respond to what the technician actually said. Never invent their
  questions or answer on their behalf.

## Workflow
1. Ask which asset they're at if you don't know. Call get_asset_info and
   briefly state the active alarms and the key live reading compared with the
   baseline.
2. Call get_maintenance_history. Point out recent work that could explain the
   fault.
3. Use the plant_manuals knowledge to choose the most likely cause and the
   procedure. Every tolerance, torque value and part number you give MUST come
   from plant_manuals or the plant tools. If you can't find it, say so. Never guess.
4. SAFETY GATE: before any hands-on step (removing guards, touching rotating
   parts, opening pressure), ask the technician to apply lockout/tagout at the
   asset's isolation points and verify zero energy. Call confirm_lockout_tagout
   only after they explicitly confirm both. If they want to skip it, politely
   refuse to give hands-on steps. You cannot apply or verify LOTO for them.
5. Guide the procedure step by step. After each completed step, call
   log_step_completed and include any measurement they read out.
6. Use check_spare_parts when a part is needed. If it's out of stock, give the
   next delivery date or the alternative.
7. When the job is done, summarise in two sentences, call create_work_order,
   read out the work order number, remind them how to remove LOTO safely, and
   then use end_conversation when they say goodbye.

## Stop-work
If the technician mentions injury, fire, smoke, a burning smell, a gas leak or
an energy source that won't isolate: tell them to stop work, step away and call
the plant emergency line on extension 2222. Don't continue the procedure.
"""

PHRASE_LIST = [
    "Torque", "Fabrikam", "P-104", "C-201", "CV-310", "FP-300", "RS-75", "LOTO", "lockout tagout",
    "MCC-3", "3B-07", "V-104S", "V-104D", "soft foot", "shim", "coupling", "drive end", "non-drive end",
    "newton metres", "millimetres", "mm per second",
]


def build_definition(use_toolbox: bool, noise: str, turn_detection: str) -> VoiceAgentDefinition:
    tools = [
        VoiceAgentFunctionTool(name=s["name"], description=s["description"],
                               parameters=RealtimeFunctionToolParameters(s["parameters"]))
        for s in FUNCTION_SCHEMAS
    ]
    tools.append(VoiceAgentEndConversationSystemTool())  # the agent can hang up by itself

    if use_toolbox:
        state = config.load_state()
        if "toolbox_version" not in state:
            raise SystemExit("No toolbox found. Run setup_knowledge.py first, or pass --no-toolbox.")
        tools.append(VoiceAgentToolboxTool(toolbox_name=state["toolbox_name"],
                                           toolbox_version=state["toolbox_version"],
                                           response_scheduling="when_idle"))

    if turn_detection == "semantic":
        td = VoiceAgentAzureSemanticVadTurnDetection(remove_filler_words=True)   # "uh... hold on" won't end the turn
    else:
        td = VoiceAgentServerVadTurnDetection(threshold=0.5, prefix_padding_ms=300, silence_duration_ms=500)

    audio_in = VoiceAgentAudioInputConfig(
        format=RealtimeAudioFormatsAudioPcm(rate=24000),
        turn_detection=td,
        echo_cancellation=VoiceAgentEchoCancellation(type="server_echo_cancellation"),
        transcription=VoiceAgentInputTranscription(model="azure-speech", phrase_list=PHRASE_LIST),
    )
    if noise == "deep":
        audio_in.noise_reduction = VoiceAgentNoiseReduction(type="azure_deep_noise_suppression")

    return VoiceAgentDefinition(
        model_type=VoiceModelType.MANAGED,          # service-managed real-time model
        model=config.VOICE_MODEL,                   # e.g. gpt-realtime (speech-to-speech)
        instructions=INSTRUCTIONS,
        greeting=VoiceAgentTemplateGreetingConfig(text="Torque here. Which machine are you working on?"),
        audio=VoiceAgentAudioConfig(
            input=audio_in,
            output=VoiceAgentAudioOutputConfig(voice=config.VOICE_NAME, voice_type=VoiceType.AZURE_STANDARD),
        ),
        output_modalities=[VoiceOutputModality.AUDIO],
        tools=tools,
        store=True,                                 # persist transcript + audio for review/evaluation
    )


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--no-toolbox", action="store_true")
    p.add_argument("--noise", choices=["deep", "off"], default="deep")
    p.add_argument("--turn-detection", choices=["semantic", "server"], default="semantic")
    p.add_argument("--description", default="Lab B - Torque field technician assistant")
    a = p.parse_args()

    definition = build_definition(not a.no_toolbox, a.noise, a.turn_detection)
    with (
        DefaultAzureCredential() as credential,
        AIProjectClient(endpoint=config.require_endpoint(), credential=credential, allow_preview=True) as project,
    ):
        version = project.agents.create_version(agent_name=config.AGENT_NAME, definition=definition,
                                                description=f"{a.description} (noise={a.noise}, vad={a.turn_detection})")
    config.save_state(agent_name=config.AGENT_NAME, agent_version=version.version)
    print(f"Created voice agent '{config.AGENT_NAME}' version {version.version} "
          f"(model={config.VOICE_MODEL}, noise={a.noise}, turn_detection={a.turn_detection}, "
          f"toolbox={'yes' if not a.no_toolbox else 'no'})")
    print("Try it in the Foundry playground, or run: python torque_app.py")


if __name__ == "__main__":
    main()
