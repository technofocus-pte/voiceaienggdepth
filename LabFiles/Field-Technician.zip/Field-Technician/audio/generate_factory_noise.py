"""Generate a synthetic 'factory floor' noise loop (24 kHz, mono, 16-bit WAV).

Mix of: low motor hum (50 Hz + harmonics), broadband machine noise,
and periodic pneumatic hiss bursts. Usage: python generate_factory_noise.py
"""

import wave
from pathlib import Path

import numpy as np

RATE, SECONDS = 24000, 30
rng = np.random.default_rng(7)
t = np.arange(RATE * SECONDS) / RATE

hum = sum(a * np.sin(2 * np.pi * f * t) for f, a in [(50, 0.30), (100, 0.20), (150, 0.10), (300, 0.05)])
brown = np.cumsum(rng.normal(0, 1, t.size)); brown -= np.convolve(brown, np.ones(2400) / 2400, mode="same")
brown /= np.max(np.abs(brown))
hiss = rng.normal(0, 1, t.size) * ((np.sin(2 * np.pi * 0.2 * t) > 0.92).astype(float))   # ~every 5 s
clank = np.zeros_like(t)
for start in np.arange(1.3, SECONDS, 3.7):
    i = int(start * RATE); n = int(0.08 * RATE)
    clank[i:i + n] += np.sin(2 * np.pi * 900 * t[:n]) * np.exp(-t[:n] * 60)

mix = 0.45 * hum + 0.35 * brown + 0.25 * hiss + 0.4 * clank
mix = (mix / np.max(np.abs(mix)) * 0.7 * 32767).astype(np.int16)

out = Path(__file__).parent / "factory_noise.wav"
with wave.open(str(out), "wb") as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(RATE); w.writeframes(mix.tobytes())
print(f"Wrote {out} ({SECONDS}s)")
