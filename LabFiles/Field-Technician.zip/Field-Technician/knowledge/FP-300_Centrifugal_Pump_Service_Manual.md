# Fabrikam FP-300 Centrifugal Pump — Service Manual (Rev. 4)

> Fictional training document for the Voice AI Engineer course. Not for use on real equipment.

## 1. Overview

The FP-300 is a horizontal end-suction centrifugal pump. It is driven by a 15 kW, 1480 rpm motor through a jaw-type flexible coupling. The bearing frame has a **drive-end (DE) bearing 6309-2Z/C3** and a **non-drive-end (NDE) bearing 6307-2Z/C3**. The shaft is sealed by a 45 mm cartridge **mechanical seal**.

| Parameter | Normal | Alarm | Trip |
|---|---|---|---|
| Overall vibration (DE bearing, velocity RMS) | ≤ 2.8 mm/s | 7.1 mm/s | 11.0 mm/s |
| Bearing housing temperature | 50–65 °C | 80 °C | 95 °C |
| Discharge pressure | 4.0–4.4 bar | < 3.5 bar | — |

## 2. Safety before any work

- Complete **lockout/tagout (LOTO)** per SOP SAF-LOTO-01 before you remove guards or touch rotating parts. Isolate **both** the electrical supply and the process water (suction and discharge valves).
- Confirm **zero energy**: try to start the pump locally, check the pressure gauge reads 0 bar, and open the casing drain.
- Bearing housings may be above 80 °C. Wear heat-resistant gloves or let them cool for 20 minutes.
- Never run the pump dry. Never run it with the coupling guard removed.

## 3. Troubleshooting — high vibration and hot bearings

Work through the causes in this order. They run from the most likely to the least likely after recent maintenance.

| Symptom | Likely cause | Check | Action |
|---|---|---|---|
| High vibration at 1× running speed, axial vibration high, DE bearing hot | **Shaft misalignment** (very common after seal or motor work) | Coupling alignment with a dial indicator or laser (Section 4) | Re-align to tolerance (Section 4). Replace the coupling insert if worn. |
| High vibration, rumbling or grinding noise, temperature rising steadily | **Bearing wear or damage** | Listen with a stethoscope, check for grease discolouration, check shaft end play | Replace the bearings (Section 5) |
| Vibration plus noisy "gravel" sound, low discharge pressure | **Cavitation** | Suction pressure, suction strainer, suction valve fully open | Clean the strainer and open the suction valve fully |
| Vibration plus a leak at the seal gland | **Mechanical seal failure** | Visual leak check | Replace the seal (Section 6) |
| Vibration at 1× that doesn't change with alignment | **Impeller imbalance or a loose foundation bolt** | Torque check on the foundation bolts | Re-torque the bolts (Section 7). If the vibration persists, send the impeller for balancing. |

**Rule of thumb:** If the seal or motor was disturbed in the last 30 days and the pump wasn't re-aligned afterwards, check alignment **first**.

## 4. Coupling alignment procedure

Tolerances for a 1480 rpm jaw coupling:

| Measurement | Tolerance |
|---|---|
| Parallel (offset) misalignment | ≤ 0.05 mm |
| Angular misalignment | ≤ 0.05 mm per 100 mm |
| Coupling gap (between hubs) | 3.0 mm ± 0.5 mm |

Steps:

1. Confirm LOTO is in place, then remove the coupling guard (4 × M8 bolts).
2. Inspect the elastomer insert. Replace it (part **FP300-CPL-INS**) if it's cracked, hardened or deformed.
3. Check for **soft foot** on the motor. Loosen each motor foot bolt in turn while watching a dial indicator. More than 0.05 mm of movement means you shim that foot (shim kit **GEN-SHIM-SS-KIT**).
4. Mount the laser or dial indicator brackets and measure vertical and horizontal offset and angularity.
5. Correct the **vertical** misalignment first with shims under the motor feet, then the **horizontal** misalignment by moving the motor sideways with the jacking bolts.
6. Tighten the motor foot bolts **to 45 N·m in a cross pattern**, then measure again.
7. Refit the insert and the coupling guard. Torque the guard bolts to **10 N·m**.
8. Remove LOTO following SOP SAF-LOTO-01, start the pump, and record the vibration after 15 minutes. The target is **≤ 2.8 mm/s**.

## 5. Bearing replacement (summary)

1. LOTO. Drain the casing and remove the coupling hub with a puller (never a hammer).
2. Remove the bearing frame end cover (6 × M10, **torque on refit 40 N·m**).
3. Press off the old bearings. Heat the new bearings to 110 °C with an induction heater. **Never use a flame.**
4. Fit the DE bearing **FP300-BRG-6309** and the NDE bearing **FP300-BRG-6307**. Fill to 30–50 % with lithium complex grease.
5. Check shaft end play: 0.05–0.15 mm.
6. Re-align the coupling (Section 4) after every bearing change.

## 6. Mechanical seal replacement (summary)

The cartridge seal kit is **FP300-SEAL-KIT**. Gland nut torque is **25 N·m**, tightened evenly in two passes. Set the seal before you remove the setting clips. Re-align the coupling afterwards (Section 4).

## 7. Torque specifications

| Fastener | Size | Torque |
|---|---|---|
| Motor foot bolts | M16 | 45 N·m |
| Pump foundation bolts | M20 | 120 N·m |
| Bearing frame end cover | M10 | 40 N·m |
| Mechanical seal gland nuts | M12 | 25 N·m |
| Casing bolts | M16 | 95 N·m (cross pattern, two passes) |
| Coupling guard | M8 | 10 N·m |
| Coupling hub set screws | M10 | 20 N·m |
