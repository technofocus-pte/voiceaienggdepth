# Fabrikam RS-75 Rotary Screw Air Compressor — Service Manual (Rev. 2)

> Fictional training document for the Voice AI Engineer course. Not for use on real equipment.

## 1. Key operating values

| Parameter | Normal | Warning | Shutdown |
|---|---|---|---|
| Discharge (airend) temperature | 75–90 °C | 100 °C | 110 °C |
| Oil pressure | 2.8–3.5 bar | < 2.5 bar | < 2.0 bar |
| Outlet pressure | 7.0–7.8 bar | — | 8.5 bar |

## 2. Safety

- LOTO per SAF-LOTO-01: breaker 1A-03, receiver valve V-201R, blow down to **0 bar**.
- Oil can be up to 95 °C. Let it cool below **50 °C** before you open the oil circuit.
- Never loosen a fitting while the system is pressurised.

## 3. Troubleshooting — high discharge temperature

| Likely cause | Check | Action |
|---|---|---|
| **Dirty oil cooler fins** (most common, especially if skipped at the last service) | Visual check of the cooler core. Measure the temperature difference across the cooler. | Clean the fins with kit **RS75-COOLER-CLN**: brush in the direction of the fins and blow out with low-pressure air from the fan side outwards. |
| Low oil level | Sight glass with the unit stopped for 5 minutes | Top up with RS-Synth 46 oil |
| Faulty thermostatic mixing valve | Oil temperature before and after the valve | Replace the element **RS75-THERMO-VLV** (opens at 71 °C) |
| High ambient temperature or blocked ventilation | Compressor room temperature above 40 °C, or a blocked louvre | Restore ventilation |

## 4. Oil cooler cleaning procedure

1. LOTO and blow down. Wait for the oil to drop below 50 °C.
2. Remove the cooler access panel (8 × M6, **refit torque 8 N·m**).
3. Spray degreaser on the fins and wait 5 minutes.
4. Brush along the fins. **Don't bend them.**
5. Blow out with air **below 2 bar** from the fan side.
6. Refit the panel, remove LOTO, run the compressor for 30 minutes, and record the discharge temperature. The target is **≤ 90 °C**.

## 5. Torque specifications

| Fastener | Torque |
|---|---|
| Cooler access panel (M6) | 8 N·m |
| Oil filter (hand tight + ¾ turn) | — |
| Oil drain plug (M20) | 50 N·m |
| Motor terminal box cover (M5) | 4 N·m |
