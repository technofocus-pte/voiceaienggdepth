# SOP SAF-LOTO-01 — Lockout/Tagout (LOTO) for Machinery Maintenance

> Fictional training document for the Voice AI Engineer course. Not for use on real equipment.

**Applies to:** all maintenance work at Zava's Dayton Plant 2 (1200 Industrial Parkway, Dayton, OH 45414) that requires removing guards, opening equipment, or reaching into any danger zone.

## 1. Golden rules

1. **No lock, no work.** Every technician applies their **own personal lock and tag** to every energy isolation point.
2. Isolate **all** energy sources listed on the asset's energy-source card: electrical, pressure (water, air, oil), stored mechanical energy (springs, raised weights) and thermal energy.
3. **Verify zero energy** before you start, every time.
4. A digital assistant **cannot** confirm LOTO for you. The technician must physically apply and verify it and then state it.

## 2. The six steps

1. **Prepare.** Identify every energy source from the asset card. Tell the area supervisor and the operators.
2. **Shut down.** Stop the equipment with its normal stop control.
3. **Isolate.** Open the breaker or disconnect, close the process valves, and bleed stored pressure.
4. **Lock and tag.** Apply your personal lock and a tag showing your name, the date and the reason, at each isolation point.
5. **Release stored energy.** Drain, vent, block or lower anything that is still stored.
6. **Verify.** Try to start the machine locally (it must not start). Check gauges read zero and test for absent voltage where required. Then return the controls to OFF.

## 3. Asset-specific isolation points

| Asset | Isolation points |
|---|---|
| P-104 (FP-300 pump) | Breaker **3B-07** on MCC-3. Suction valve **V-104S** and discharge valve **V-104D** closed and chained. Casing drain open. |
| C-201 (RS-75 compressor) | Breaker **1A-03** on MCC-1. Receiver isolation valve **V-201R** closed. Blow down to 0 bar. Allow the oil to cool below 50 °C. |
| CV-310 (conveyor) | Breaker **4C-11** on MCC-4. Lower the gravity take-up weight onto its stops. |

## 4. Removing LOTO

Before removing locks: tools are cleared, guards are refitted, everyone is clear, the operators are told, and **each technician removes only their own lock**.

## 5. Stop-work conditions

Stop and call the shift supervisor (extension **2200**) if you find any of these:
- an isolation point that won't lock,
- an unexpected energy source,
- a gas or oil leak, smoke, or a burning smell,
- an injury of any kind. For emergencies, call the **plant emergency line on extension 2222**.
