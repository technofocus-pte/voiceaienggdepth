import { config, assertCallConfig, isSimulated } from "../src/config.mjs";

console.log("Port            :", config.port);
console.log("Voice model     :", config.voiceLive.model);
console.log("Locations file  :", config.pricing.locationsPath);
console.log("Freshness       :", config.pricing.futuresStaleMinutes, "min (hard limit", config.pricing.futuresHardLimitMinutes, "min)");
console.log("Missing for live:", assertCallConfig().join(", ") || "(nothing)");
console.log("Simulation mode :", isSimulated());
