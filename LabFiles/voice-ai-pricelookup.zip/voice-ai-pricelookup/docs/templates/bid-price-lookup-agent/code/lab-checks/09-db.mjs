import { SqliteAudit } from "../src/db.mjs";

const audit = new SqliteAudit(":memory:");   // an in-memory database, so nothing is written to disk
audit.startCall({ id: "call-1", maskedPhone: "+••••••••12", state: "ringing", startedAt: new Date().toISOString(), simulated: true });
audit.recordQuote("call-1", { commodity: "corn", locationId: "riverside", freshness: "close", phrase: "As of the last close ..." });
audit.updateCall("call-1", { outcome: "caller_done" });
const s = audit.stats();
console.log("Store:", audit.name, "| calls:", s.calls, "| quotes:", s.quotesGiven, "| close-price quotes:", s.closePriceQuotes);
audit.close();
