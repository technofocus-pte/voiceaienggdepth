import { createHub } from "../src/realtime.mjs";

const hub = createHub();
console.log("Transport:", hub.transport);
console.log("Console connects to:", hub.negotiate("*").url);
hub.send("call-1", "transcript", { role: "agent", text: "Hello" });
console.log("Message queued for consoles that connect later: OK");
