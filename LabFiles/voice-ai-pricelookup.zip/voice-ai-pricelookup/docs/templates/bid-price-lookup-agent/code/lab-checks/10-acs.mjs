import { answerInboundCall, transferToTeams, startDtmfRecognition, hangUp, acsClient } from "../src/voice/acs.mjs";

console.log("Exports:", [answerInboundCall, transferToTeams, startDtmfRecognition, hangUp].map((f) => f.name).join(", "));
try {
  await acsClient();
  console.log("ACS client created (ACS_ENDPOINT is set)");
} catch (e) {
  console.log("Expected without .env:", e.message);
}
