import { VoiceLiveSession, AGENT_TOOLS } from "../src/voice/voice-live.mjs";

const session = new VoiceLiveSession({ instructions: "test", onAgentAudio: () => {} });
console.log("Session object created; connected yet?", !session.closed && Boolean(session.ws));
console.log("Tools it will register with Voice Live:", AGENT_TOOLS.length);
