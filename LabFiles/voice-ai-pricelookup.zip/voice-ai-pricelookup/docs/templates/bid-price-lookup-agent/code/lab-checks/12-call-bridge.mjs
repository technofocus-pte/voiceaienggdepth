import { attachMediaBridge, activeBridges } from "../src/voice/call-bridge.mjs";
import { BidLookupFlow } from "../src/flow.mjs";
import { MemoryAudit } from "../src/audit.mjs";
import { PriceBook } from "../src/pricing.mjs";

const flow = new BidLookupFlow({ priceBook: new PriceBook(), audit: new MemoryAudit() });
const wss = attachMediaBridge(flow);
console.log("Media bridge ready; active calls:", activeBridges.size);
wss.close();
