import { AGENT_TOOLS, forModel, buildInstructions } from "../src/agent.mjs";
import { PriceBook } from "../src/pricing.mjs";

console.log("Tools the AI may call:", AGENT_TOOLS.map((t) => t.name).join(", "));

const fullResult = { ok: true, phrase: "Corn at Riverside ... $4.12 ...", cashBid: 4.12, basisCents: -35, futuresPrice: 4.47 };
console.log("What the server knows :", Object.keys(fullResult).join(", "));
console.log("What the AI receives  :", Object.keys(forModel(fullResult)).join(", "));

const instructions = buildInstructions(new PriceBook(), "en-US");
console.log("\nFirst lines of the AI instructions:\n" + instructions.split("\n").slice(0, 3).join("\n"));
