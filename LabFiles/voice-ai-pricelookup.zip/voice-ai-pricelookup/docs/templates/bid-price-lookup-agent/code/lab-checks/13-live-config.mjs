import { config, readiness, isSimulated } from "../src/config.mjs";
import { PriceBook } from "../src/pricing.mjs";

const r = readiness(new PriceBook());
console.log("Mode              :", isSimulated() ? "SIMULATION (something is missing)" : "LIVE");
console.log("PUBLIC_BASE_URL   :", config.publicBaseUrl || "(missing)");
console.log("ACS_ENDPOINT      :", config.acs.endpoint || "(missing)", "| auth:", r.telephony.auth);
console.log("VOICE_LIVE        :", config.voiceLive.endpoint || "(missing)", "| auth:", r.voiceLive.auth);
console.log("Locations file    :", config.pricing.locationsPath);
console.log("Merchandisers set :", r.teams.ready ? "yes, all locations" : "NO - placeholders at " + r.teams.unprovisionedLocations.join(", "));
if (/\/models$/.test(config.voiceLive.endpoint)) console.log("WARNING: VOICE_LIVE_ENDPOINT must not end in /models");
