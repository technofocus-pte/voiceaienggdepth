import { teamsIdentifier, buildCustomCallingContext } from "../src/handoff.mjs";

console.log(teamsIdentifier({ type: "user", objectId: "11111111-2222-3333-4444-555555555555" }));
console.log(teamsIdentifier({ type: "callQueue", objectId: "66666666-7777-8888-9999-000000000000" }));
console.log(buildCustomCallingContext({
  sessionId: "abc-123",
  callTopic: "Sell corn – Riverside",
  callContext: "Last quote: Corn at Riverside ... Reason: Caller wants to sell.",
  locationId: "riverside",
  reason: "sell_request",
}));
