import { MemoryAudit } from "../src/audit.mjs";

const audit = new MemoryAudit();
audit.startCall({ id: "call-1", maskedPhone: "+••••••••12", state: "ringing", simulated: true });
audit.recordQuote("call-1", { commodity: "corn", locationId: "riverside", freshness: "live", phrase: "Corn at Riverside ..." });
audit.updateCall("call-1", { outcome: "caller_done" });
const s = audit.stats();
console.log("Calls:", s.calls, "| automated:", s.callsAutomated, "| quotes:", s.quotesGiven, "| staff minutes saved:", s.estimatedStaffMinutesSaved);
