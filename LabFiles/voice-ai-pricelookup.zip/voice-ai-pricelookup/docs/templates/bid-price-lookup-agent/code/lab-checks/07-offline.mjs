import { BidLookupFlow } from "../src/flow.mjs";
import { MemoryAudit } from "../src/audit.mjs";
import { PriceBook, LocationDirectory, FixtureFeed } from "../src/pricing.mjs";
import { handleUtterance } from "../src/offline.mjs";

const priceBook = new PriceBook({ locations: LocationDirectory.load(), feed: new FixtureFeed(), now: () => new Date("2026-09-08T10:45:00-05:00") });
const flow = new BidLookupFlow({ priceBook, audit: new MemoryAudit() });
const call = flow.create({ fromPhone: "+15555550112", simulated: true });
flow.answered(call.id);

for (const line of ["What's corn paying at the river elevator?", "Riverside.", "Okay, lock in 5,000 bushels at that price."]) {
  handleUtterance(flow, call.id, line);
}
await flow.settled(call.id);
for (const t of flow.get(call.id).transcript) console.log(`${t.role.padEnd(6)}: ${t.text}`);
