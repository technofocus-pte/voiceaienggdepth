import { BidLookupFlow } from "../src/flow.mjs";
import { MemoryAudit } from "../src/audit.mjs";
import { PriceBook, LocationDirectory, FixtureFeed } from "../src/pricing.mjs";

const priceBook = new PriceBook({
  locations: LocationDirectory.load(),
  feed: new FixtureFeed(),
  now: () => new Date("2026-09-08T10:45:00-05:00"),
});
const flow = new BidLookupFlow({ priceBook, audit: new MemoryAudit() });

const call = flow.create({ fromPhone: "+15555550112", simulated: true });
flow.answered(call.id);
flow.getBid(call.id, { commodity: "corn", location: "Riverside" });
flow.getBid(call.id, { commodity: "beans" });                 // follow-up: reuses Riverside
flow.adviceBoundary(call.id);                                 // "should I sell?"
flow.transferToMerchandiser(call.id, { reason: "sell_request" });
await flow.settled(call.id);

for (const line of flow.get(call.id).transcript) console.log(`${line.role.padEnd(6)}: ${line.text}`);
console.log("Final state:", flow.get(call.id).state, "| outcome:", flow.get(call.id).outcome);
console.log("Teams topic:", flow.handoffContext(flow.get(call.id)).callTopic);
