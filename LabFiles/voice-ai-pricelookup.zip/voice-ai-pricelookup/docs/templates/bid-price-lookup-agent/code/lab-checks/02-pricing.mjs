import { PriceBook, LocationDirectory, FixtureFeed } from "../src/pricing.mjs";

const bookAt = (iso) => new PriceBook({
  locations: LocationDirectory.load(),
  feed: new FixtureFeed(),
  now: () => new Date(iso),
  options: { softStaleMinutes: 20, hardLimitMinutes: 240 },
});

const fresh  = bookAt("2026-09-08T10:45:00-05:00");   // the "Prices fresh" demo morning
const stale  = bookAt("2026-09-08T11:20:00-05:00");   // futures are now older than 20 minutes
const closed = bookAt("2026-09-08T14:00:00-05:00");   // the futures market closed at 1:20 PM

console.log("1.", fresh.quote({ commodity: "corn", location: "Riverside" }).phrase);
console.log("2.", stale.quote({ commodity: "beans", location: "riverside" }).phrase);
console.log("3.", closed.quote({ commodity: "corn", location: "north elevator" }).phrase);
console.log("4.", fresh.quote({ commodity: "corn", location: "river" }).message);
console.log("5.", fresh.quote({ location: "Fairview" }).message);
console.log("6.", fresh.list({ commodity: "corn" }).phrases.length, "locations, highest first:", fresh.list({ commodity: "corn" }).quotes.map((q) => `${q.locationName} $${q.cashBid.toFixed(2)}`).join(", "));
