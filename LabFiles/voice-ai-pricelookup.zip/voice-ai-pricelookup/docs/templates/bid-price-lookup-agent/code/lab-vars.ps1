# ======================= EDIT THESE =======================
$TENANT  = "<Lab tenant>"     		 # the lab tenant
$SUFFIX  = "<suffix>"                    # e.g. the suffix number in the labVM
$LOC     = "eastus2"                     # a region that serves gpt-realtime for Voice Live
$MERCH   = "<Login id>"   		 # your login id in the lab VM
$TUNNEL  = "bidline-$SUFFIX"             # dev tunnel name
# ===================== DERIVED NAMES ======================
$RG  = "rg-bidline-$SUFFIX"
$ACS = "acs-bidline-$SUFFIX"
$AI  = "ai-bidline-$SUFFIX"                    # must be globally unique
# ============ FETCHED FROM AZURE (after Step 15) ===========
$ACSID        = az communication show -n $ACS -g $RG --query id -o tsv 2>$null
$ACS_ENDPOINT = if ($ACSID) { "https://" + (az communication show -n $ACS -g $RG --query hostName -o tsv) }
$IMMUTABLE    = if ($ACSID) { az communication show -n $ACS -g $RG --query immutableResourceId -o tsv }
$AISUB        = az cognitiveservices account show -n $AI -g $RG --query properties.customSubDomainName -o tsv 2>$null
$VL_ENDPOINT  = if ($AISUB) { "https://$AISUB.services.ai.azure.com" }
$MERCH_ID     = az ad user show --id $MERCH --query id -o tsv 2>$null
"Tenant      : $TENANT"
"ACS         : $ACS_ENDPOINT"
"Voice Live  : $VL_ENDPOINT"
"Merchandiser: $MERCH_ID"
