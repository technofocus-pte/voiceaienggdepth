# lab-vars.ps1 - load it in every PowerShell 7 window with:   . .\lab-vars.ps1
# ---------------------------------------------------------------- EDIT
$TENANT = "<Lab tenant>"				  # the lab tenant
$SUFFIX = "<suffix>"                                	  # the suffix number in the labVM
$LOC    = "eastus2"                                       # a region that serves Voice Live (gpt-realtime)
$AGENT  = "<Login id>"     				  # your login id in the lab VM
# ------------------------------------------------- derived (do not edit)
$TUNNEL = "callroute-$SUFFIX"
$RG  = "rg-callroute-$SUFFIX"; $ACS = "acs-callroute-$SUFFIX"; $AI = "ai-callroute-$SUFFIX"
$ACSID        = az communication show -n $ACS -g $RG --query id -o tsv 2>$null
$ACS_ENDPOINT = if ($ACSID) { "https://" + (az communication show -n $ACS -g $RG --query hostName -o tsv) }
$IMMUTABLE    = if ($ACSID) { az communication show -n $ACS -g $RG --query immutableResourceId -o tsv }
$AISUB        = az cognitiveservices account show -n $AI -g $RG --query properties.customSubDomainName -o tsv 2>$null
$VL_ENDPOINT  = if ($AISUB) { "https://$AISUB.services.ai.azure.com" }
$AGENT_ID     = az ad user show --id $AGENT --query id -o tsv 2>$null

Write-Host "Resource group : $RG"
Write-Host "ACS endpoint   : $ACS_ENDPOINT"
Write-Host "ACS immutable  : $IMMUTABLE"
Write-Host "Voice Live     : $VL_ENDPOINT"
Write-Host "Teams user ID  : $AGENT_ID"
Write-Host "Tunnel         : $TUNNEL"
# ------------------------------------- added after the tunnel starts
