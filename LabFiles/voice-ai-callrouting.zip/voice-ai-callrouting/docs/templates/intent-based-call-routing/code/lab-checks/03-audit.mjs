import { MemoryAudit } from "../src/audit.mjs";

const audit = new MemoryAudit();
audit.startCall({ id: "call-1", state: "ringing", simulated: true });
audit.recordEvent("call-1", "agent", "clarification", "low_confidence (1)");
audit.recordEvent("call-1", "system", "transfer_simulated", "billing");
audit.updateCall("call-1", { confirmedRouteId: "billing", outcome: "transferred:billing", durationMs: 21000 });

console.log("Events for call-1:", audit.eventsFor("call-1").map((e) => e.kind).join(", "));
console.log("Stats:", audit.stats());
