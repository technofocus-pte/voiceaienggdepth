import { config, readiness, isSimulated } from "../src/config.mjs";
import { RoutePolicy } from "../src/routes.mjs";

const routes = RoutePolicy.load();
const r = readiness(routes);
console.log("Mode              :", isSimulated() ? "SIMULATION (something is missing)" : "LIVE");
console.log("PUBLIC_BASE_URL   :", config.publicBaseUrl || "(missing)");
console.log("ACS_ENDPOINT      :", config.acs.endpoint || "(missing)", "| auth:", r.telephony.auth);
console.log("VOICE_LIVE        :", config.voiceLive.endpoint || "(missing)", "| auth:", r.voiceLive.auth);
console.log("Routes file       :", config.routing.routesPath);
console.log("Teams targets set :", r.teams.ready ? "yes, all routes" : "NO - placeholders at " + r.teams.unprovisionedRoutes.join(", "));
for (const id of routes.ids) {
  const t = routes.get(id).target;
  console.log(`  ${id.padEnd(10)}: ${t.type} ${t.objectId} | ${routes.describeHours(id).hours}`);
}
if (/\/models$/.test(config.voiceLive.endpoint)) console.log("WARNING: VOICE_LIVE_ENDPOINT must not end in /models");
