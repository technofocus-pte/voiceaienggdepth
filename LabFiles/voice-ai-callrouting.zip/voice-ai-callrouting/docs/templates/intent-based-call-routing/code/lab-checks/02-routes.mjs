import { RoutePolicy, CallerDirectory, maskPhone } from "../src/routes.mjs";

const routes = RoutePolicy.load();
const businessHours = new Date("2026-09-30T10:30:00-07:00"); // a Wednesday morning, Pacific time
const afterHours = new Date("2026-09-30T19:30:00-07:00");    // the same day, in the evening

console.log("Organisation :", routes.organization, "| fallback:", routes.fallbackRouteId);
console.log("Route ids    :", routes.ids.join(", "));
console.log("Keypad 3     :", routes.routeForDigit("3"));
console.log("Billing open at 10:30 :", routes.isOpen("billing", businessHours));
console.log("Billing open at 19:30 :", routes.isOpen("billing", afterHours));
const b = routes.resolve("billing", afterHours);
console.log("Billing after hours   :", b.action);
const s = routes.resolve("sales", afterHours);
console.log("Sales after hours     :", s.action, "to", s.routeId, "(diverted from", s.divertedFrom + ")");
console.log("Hours (billing)       :", routes.describeHours("billing"));

const callers = CallerDirectory.load();
console.log("Caller +14255550101   :", callers.lookup("+1 (425) 555-0101"));
console.log("Masked number         :", maskPhone("+14255550101"));
