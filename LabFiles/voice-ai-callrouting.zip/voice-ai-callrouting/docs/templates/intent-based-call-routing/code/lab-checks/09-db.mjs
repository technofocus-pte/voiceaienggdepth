import { SqliteAudit } from "../src/db.mjs";

const audit = new SqliteAudit(":memory:"); // an in-memory database, so nothing is written to disk
audit.startCall({ id: "call-1", maskedPhone: "+•••••••••01", state: "ringing", startedAt: new Date().toISOString(), simulated: true });
audit.recordEvent("call-1", "agent", "route_proposed", "billing @ 0.95");
audit.recordEvent("call-1", "system", "transfer_simulated", "billing");
audit.updateCall("call-1", { confirmedRouteId: "billing", outcome: "transferred:billing", durationMs: 18000 });
const s = audit.stats();
console.log("Store:", audit.name, "| calls:", s.calls, "| transfers:", s.transfers, "| by route:", JSON.stringify(s.byRoute), "| median seconds to route:", s.medianSecondsToRoute);
audit.close();
