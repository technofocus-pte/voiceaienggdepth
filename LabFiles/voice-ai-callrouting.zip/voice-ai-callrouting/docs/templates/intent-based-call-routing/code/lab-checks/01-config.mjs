import { config, assertCallConfig, isSimulated } from "../src/config.mjs";

console.log("Port             :", config.port);
console.log("Voice model      :", config.voiceLive.model);
console.log("Routes file      :", config.routing.routesPath);
console.log("Callers file     :", config.routing.callersPath);
console.log("Confidence gate  :", config.routing.confidenceThreshold);
console.log("Route time budget:", config.routing.timeBudgetMs / 1000, "s | clarifications allowed:", config.routing.maxClarifications);
console.log("Missing for live :", assertCallConfig().join(", ") || "(nothing)");
console.log("Simulation mode  :", isSimulated());
