import { attachMediaBridge, activeBridges } from "../src/voice/call-bridge.mjs";
import { RoutingFlow } from "../src/flow.mjs";
import { RoutePolicy } from "../src/routes.mjs";
import { MemoryAudit } from "../src/audit.mjs";

const flow = new RoutingFlow({ routes: RoutePolicy.load(), audit: new MemoryAudit() });
const wss = attachMediaBridge(flow);
console.log("Media bridge ready; active calls:", activeBridges.size);
wss.close();
