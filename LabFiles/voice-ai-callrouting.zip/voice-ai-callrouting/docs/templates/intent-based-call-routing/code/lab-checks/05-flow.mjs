import { RoutingFlow } from "../src/flow.mjs";
import { RoutePolicy, CallerDirectory } from "../src/routes.mjs";
import { MemoryAudit } from "../src/audit.mjs";

const flow = new RoutingFlow({
  routes: RoutePolicy.load(),
  callers: CallerDirectory.load(),
  audit: new MemoryAudit(),
  now: () => Date.parse("2026-09-30T10:30:00-07:00"), // business hours
  options: { transferDelayMs: 0 },
});

const call = flow.create({ fromPhone: "+14255550101", simulated: true });
// Stand-in for the AI: print the example line the flow gives with each instruction.
flow.registerAgent(call.id, { instruct: (_text, spoken) => spoken && console.log("agent :", spoken) });

flow.answered(call.id);
const step = (label, args) => {
  console.log("model :", label);
  const r = flow.proposeRoute(call.id, args);
  console.log("server:", r.clarify ? `below the gate - clarify (${r.reason})` : r.ok ? "accepted - ask the caller to confirm" : `refused (${r.reason})`);
};
step("propose billing, confidence 0.5", { routeId: "billing", confidence: 0.5, callTopic: "Renewal charge" });
step("propose payroll, confidence 0.9", { routeId: "payroll", confidence: 0.9, callTopic: "Payroll" });
step("propose billing, confidence 0.95", { routeId: "billing", confidence: 0.95, callTopic: "Charged twice", callSummary: "Charged twice on the March invoice." });
console.log("caller: yes  -> confirm_route billing");
flow.confirmRoute(call.id, "billing");
await flow.settled(call.id);

const done = flow.get(call.id);
console.log("Final state:", done.state, "| outcome:", done.outcome, "| clarifications:", done.clarifications);
const { sessionId, ...context } = flow.handoffContext(done);
console.log("Teams receives:", context);
