import { teamsIdentifier, buildCustomCallingContext, resourceAccountFrom } from "../src/handoff.mjs";

console.log("User target  :", teamsIdentifier({ type: "user", objectId: "11111111-2222-3333-4444-555555555555" }));
console.log("Queue target :", teamsIdentifier({ type: "callQueue", objectId: "66666666-7777-8888-9999-000000000000" }));
console.log("Resource account in a Teams call:", resourceAccountFrom({ rawId: "28:orgid:66666666-7777-8888-9999-000000000000" }));
console.log("Resource account in an ACS call :", resourceAccountFrom({ rawId: "4:+14255550199" }));
console.log("VoIP headers:");
console.log(buildCustomCallingContext({
  sessionId: "abc-123",
  callTopic: "Charged twice on my invoice",
  callContext: "Caller was charged twice on the March invoice.",
  routeId: "billing",
  afterHours: false,
  callerDetails: { name: "Dana Whitfield", company: "Northwind Traders", verified: false },
}));
