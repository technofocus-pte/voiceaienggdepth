import { answerInboundCall, transferToTeams, startDtmfRecognition, hangUp, acsClient, asciiSafe, buildCustomCallingContext } from "../src/voice/acs.mjs";

console.log("Exports:", [answerInboundCall, transferToTeams, startDtmfRecognition, hangUp].map((f) => f.name).join(", "));

const headers = buildCustomCallingContext({ sessionId: "abc-123", callTopic: "Renewal charge – “not ordered”…", routeId: "billing" });
console.log("Headers built         :", headers.map((h) => `${h.key}=${h.value}`).join(" | "));
console.log("Headers sent to Teams :", asciiSafe(headers).map((h) => `${h.key}=${h.value}`).join(" | "));

try {
  await acsClient();
  console.log("ACS client created (ACS_ENDPOINT is set)");
} catch (e) {
  console.log("Expected without .env:", e.message);
}
