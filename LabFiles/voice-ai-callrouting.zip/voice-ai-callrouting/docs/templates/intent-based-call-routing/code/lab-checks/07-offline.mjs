import { RoutingFlow } from "../src/flow.mjs";
import { RoutePolicy, CallerDirectory } from "../src/routes.mjs";
import { MemoryAudit } from "../src/audit.mjs";
import { handleUtterance, registerSimulatedAgent, classifyOffline } from "../src/offline.mjs";

console.log("classify 'I was charged twice on my invoice':", classifyOffline("I was charged twice on my invoice"));

const flow = new RoutingFlow({
  routes: RoutePolicy.load(),
  callers: CallerDirectory.load(),
  audit: new MemoryAudit(),
  now: () => Date.parse("2026-09-30T10:30:00-07:00"),
  options: { transferDelayMs: 0 },
});
const call = flow.create({ fromPhone: "+14255550101", simulated: true });
registerSimulatedAgent(flow, call.id);
flow.answered(call.id);

for (const line of ["I was charged for a renewal I did not order", "There's a charge on my invoice I need refunded", "Yes please"]) {
  handleUtterance(flow, call.id, line);
}
await flow.settled(call.id);
console.log("");
for (const t of flow.get(call.id).transcript) console.log(`${t.role.padEnd(6)}: ${t.text}`);
console.log("\nOutcome:", flow.get(call.id).outcome);
