import { AGENT_TOOLS, buildInstructions, localeLanguage } from "../src/agent.mjs";
import { RoutePolicy } from "../src/routes.mjs";

console.log("Tools the AI may call:", AGENT_TOOLS.map((t) => t.name).join(", "));
const params = AGENT_TOOLS.flatMap((t) => Object.keys(t.parameters.properties));
console.log("Any tool that takes a phone number, object id or URL?", params.some((p) => /phone|object|url|target/i.test(p)) ? "YES" : "no");
console.log("Locale:", localeLanguage("en-US"));

const instructions = buildInstructions(RoutePolicy.load(), "en-US");
const menu = instructions.split("\n").filter((l) => l.startsWith("- ") && l.includes("Keypad"));
console.log("\nRoute menu the AI is given:\n" + menu.join("\n"));
